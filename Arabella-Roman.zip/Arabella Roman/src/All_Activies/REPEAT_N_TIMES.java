package All_Activies;
    import java.util.Scanner;
public class REPEAT_N_TIMES {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n;
        System.out.println("\nREPEAT N-TIMES - Using DO-WHILE loop");
        System.out.printf("input an integer value for N: ");
        n = input.nextInt();
        do {
            System.out.printf("%d ANG POGI NI SIR JAMES\n", n);
            n = n - 1;
        } while (n > 0);
    }
}
