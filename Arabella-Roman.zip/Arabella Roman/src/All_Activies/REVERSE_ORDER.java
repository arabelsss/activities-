package All_Activies;

import java.util.Scanner;

public class REVERSE_ORDER {
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
        int n;
        n = 10;

        System.out.println("\nREVERSE ORDER");
        System.out.printf("input 10 integers to be stored in an array: ");

        int[] array1 = new int[n];
        int[] array2 = new int[n];

        for (int i = 0; i < n; i++) {
            array1[i] = input.nextInt(); // get integer number            
            array2[n - 1 - i] = array1[i]; // runs from index (n - 1) - i to 0
        }

        System.out.println("\nelement of array1 and array2:");
        for (int i = 0; i < n; i++) {
            System.out.printf("array1[%d] = %d vs. array2[%d] = %d\n",
                    i, array1[i], i, array2[i]);
        } 
        
    }
}
